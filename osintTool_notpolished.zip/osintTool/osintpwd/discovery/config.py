"""Environment-driven configuration for discovery backends.

Nothing secret is hardcoded. Set only what you use:

    SERPER_API_KEY      -> enables Serper.dev (google.serper.dev)
    GOOGLE_CSE_KEY      -> Google Custom Search JSON API key
    GOOGLE_CSE_CX       -> Google Custom Search engine id (cx)
    SEARXNG_URL         -> base URL of your SearXNG instance
                           (default http://localhost:8080)
    OSINT_BACKEND_ORDER -> comma list to force priority, e.g.
                           "serper,searxng,playwright,duckduckgo"
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class DiscoveryConfig:
    serper_key: str = ""
    google_cse_key: str = ""
    google_cse_cx: str = ""
    searxng_url: str = ""          # empty => SearXNG disabled
    backend_order: tuple[str, ...] = ()

    @classmethod
    def from_env(cls) -> "DiscoveryConfig":
        order = os.environ.get("OSINT_BACKEND_ORDER", "")
        return cls(
            serper_key=os.environ.get("SERPER_API_KEY", "").strip(),
            google_cse_key=os.environ.get("GOOGLE_CSE_KEY", "").strip(),
            google_cse_cx=os.environ.get("GOOGLE_CSE_CX", "").strip(),
            # SearXNG only joins the chain when explicitly configured, so an
            # absent instance never stalls the fallback on connect retries.
            searxng_url=os.environ.get("SEARXNG_URL", "").strip(),
            backend_order=tuple(
                x.strip() for x in order.split(",") if x.strip()
            ),
        )
