"""Per-run query reuse and observable, thread-safe search accounting."""
from __future__ import annotations

from concurrent.futures import Future
from dataclasses import replace
import threading
import time
from urllib.parse import urlsplit


def _valid_url(url):
    if not isinstance(url, str):
        return False
    try:
        parsed = urlsplit(url)
        return parsed.scheme in ('http', 'https') and bool(parsed.hostname)
    except (TypeError, ValueError):
        return False


class SearchRun:
    def __init__(self, backend):
        self.backend = backend
        self._cache: dict[tuple[str, int, str, str], Future] = {}
        self._lock = threading.Lock()
        self.records: list[dict] = []
        self.cache_hits = 0

    def is_available(self):
        return self.backend.is_available()

    @property
    def errors(self):
        return getattr(self.backend, 'errors', [])

    def search(self, query: str, max_results: int = 20):
        return self._search(query, max_results)

    def search_profiles(self, query: str, max_results: int = 20, *, platform: str, name: str):
        return self._search(query, max_results, platform, name)

    def _search(self, query: str, max_results: int, platform: str = '', name: str = ''):
        # A larger prior request can satisfy the smaller related-search request.
        # Generic hits cannot satisfy a profile-qualified lookup: they may have
        # stopped the provider chain at a directory or an unrelated account.
        key = (query, max_results, platform, name)
        with self._lock:
            prior = next((future for (q, n, p, target), future in self._cache.items()
                          if q == query and n >= max_results and (p, target) == (platform, name)), None)
            owner = prior is None
            if owner:
                prior = self._cache[key] = Future()
            else:
                self.cache_hits += 1
        if not owner:
            return [replace(hit) for hit in prior.result()[:max_results]]
        started = time.monotonic()
        record = {'query': query, 'max_results': max_results, 'status': 'ok'}
        if platform:
            record.update(platform=platform, target_name=name, mode='profiles')
        try:
            profile_search = getattr(self.backend, 'search_profiles', None)
            if platform and callable(profile_search):
                hits = profile_search(query, max_results=max_results, platform=platform, name=name) or []
            else:
                hits = self.backend.search(query, max_results=max_results) or []
            record['invalid_results'] = sum(not _valid_url(hit.url) for hit in hits)
            hits = [hit for hit in hits if _valid_url(hit.url)]
            provider = getattr(self.backend, 'name', '')
            hits = [replace(hit, query=query, provider=hit.provider or provider) for hit in hits]
            record.update(results=len(hits), providers=sorted({h.provider for h in hits}))
            if not hits:
                record['status'] = 'empty'
            prior.set_result(hits)
            return [replace(hit) for hit in hits]
        except Exception as exc:
            record.update(status='error', error=type(exc).__name__, results=0)
            prior.set_exception(exc)
            raise
        finally:
            record['seconds'] = round(time.monotonic() - started, 3)
            with self._lock:
                self.records.append(record)

    def stats(self):
        attempts = list(getattr(self.backend, 'attempts', []))
        return {'search_queries': len(self.records), 'search_cache_hits': self.cache_hits,
                'query_errors': sum(r['status'] == 'error' for r in self.records),
                'empty_queries': sum(r['status'] == 'empty' for r in self.records),
                'provider_requests': len(attempts),
                'provider_errors': sum(r['status'] == 'error' for r in attempts),
                'provider_attempts': sorted(attempts, key=lambda r: (r['query'], r['provider'])),
                'queries': sorted(self.records, key=lambda r: r['query'])}
