"""Bounded co-mention discovery with a verifiable one-hop source chain.

A co-mention supplies a lead, never an identity claim. An associate's profile
stays separate even if its snippet mentions the target. Target proposals need
an owner-name hit or an explicitly name-attached link on the associate page.
"""
from __future__ import annotations

import re
import unicodedata

from .candidates import (
    PLATFORMS, build_extra_query, build_queries, canonical_candidate_key,
    classify, is_name_match, merge_candidate,
)
from .enrich import enrich_candidate
from .http import PoliteClient
from .models import Candidate, SearchResult
from .translit import name_variants

_UPPER = "A-ZÀ-ÖØ-ÞА-ЯЁӘҒҚҢӨҰҮҺІ"
_LOWER = "a-zà-öø-ÿа-яёәғқңөұүһі"
_PERSON = re.compile(rf"\b[{_UPPER}][{_LOWER}'’-]+(?:\s+[{_UPPER}][{_LOWER}'’-]+){{1,2}}\b")
_STOP = {"university", "institute", "school", "college", "news", "press",
         "company", "bank", "republic", "region", "city", "google", "facebook",
         "instagram", "linkedin", "twitter", "университет", "институт", "школа",
         "академия", "банк", "новости", "область", "город", "республика",
         "университеті", "мектебі", "қаласы"}
_SOCIAL_SITES = ("site:linkedin.com/in", "site:instagram.com", "site:facebook.com",
                 "site:vk.com", "site:x.com", "site:t.me", "site:github.com")


def _tokens(text: str) -> set[str]:
    text = unicodedata.normalize("NFKC", text or "").casefold().replace("ё", "е")
    return {w for w in re.findall(r"[^\W_]+", text) if len(w) > 1}


def _aliases(name: str, variants: list[str] | None = None) -> list[str]:
    return list(dict.fromkeys(v.strip() for v in [name, *(variants or name_variants(name))]
                              if v and v.strip()))[:6]


def target_contexts(name: str, text: str, limit: int = 25, *,
                    variants: list[str] | None = None) -> list[str]:
    """Short paragraphs containing all tokens of one target-name variant."""
    targets = [_tokens(v) for v in _aliases(name, variants) if _tokens(v)]
    out: list[str] = []
    for para in re.split(r"[\r\n]+", (text or "")[:24_000]):
        chunks = [para] if len(para) <= 800 else re.split(r"(?<=[.!?])\s+", para)
        for chunk in chunks:
            # A very long unpunctuated block is not a meaningful co-mention.
            windows = [chunk] if len(chunk) <= 800 else [
                chunk[i:i + 800] for i in range(0, len(chunk), 600)]
            for window in windows:
                window = window.strip()
                if (window and any(t <= _tokens(window) for t in targets)
                        and window not in out):
                    out.append(window)
                    if len(out) >= limit:
                        return out
    return out


def _people_in(context: str) -> tuple[list[str], set[str]]:
    """Optional multilingual NER supplemented by RU/KZ/Latin name patterns."""
    people: list[str] = []
    orgs: set[str] = set()
    try:
        from ..ml.ner import extract_entities
        ent = extract_entities(context)
        people = list(ent.persons)
        orgs = {o.casefold() for o in (ent.orgs + ent.locations)}
    except Exception:
        pass
    # A model may recognize the target alone and miss a Kazakh associate.
    people.extend(_PERSON.findall(context))
    return list(dict.fromkeys(people)), orgs


def nearby_people(name: str, sources: list[tuple[str, str]],
                  limit: int = 3, *, variants: list[str] | None = None) -> list[dict]:
    """Rank co-mentioned names by distinct source URLs; retain every excerpt."""
    targets = [_tokens(v) for v in _aliases(name, variants)]
    found: dict[str, dict] = {}
    for url, text in sources[:80]:
        for ctx in target_contexts(name, text, variants=variants):
            people, orgs = _people_in(ctx)
            for person in people:
                toks = _tokens(person)
                if (len(toks) < 2 or any(t and t <= toks for t in targets)
                        or toks & _STOP or person.casefold() in orgs):
                    continue
                key = " ".join(sorted(toks))
                item = found.setdefault(key, {"name": person.strip(), "url": url,
                                             "excerpt": ctx[:600], "evidence": []})
                ev = {"kind": "co_mention", "source_url": url, "excerpt": ctx[:600],
                      "related_person": item["name"], "query": "", "provider": ""}
                if ev not in item["evidence"]:
                    item["evidence"].append(ev)
    for item in found.values():
        item["sources"] = len({e["source_url"] for e in item["evidence"]})
    return sorted(found.values(), key=lambda p: p["sources"], reverse=True)[:max(0, limit)]


def _link_names_target(link: dict, aliases: list[str]) -> bool:
    """An anchor names its account; page-wide mentions do not establish this."""
    anchor = _tokens(link.get("anchor", ""))
    if any(_tokens(v) <= anchor for v in aliases if _tokens(v)):
        # A group label naming several people cannot identify the linked owner.
        alias_tokens = [_tokens(v) for v in aliases]
        if any(not any(t <= _tokens(p) for t in alias_tokens)
               for p in _PERSON.findall(link.get("anchor", ""))):
            return False
        return True
    # A label such as 'Aslan Serikov: @asik' binds a handle without a name anchor.
    context = link.get("context", "")
    label = link.get("anchor", "").strip()
    if not label or len(context) > 350:
        return False
    for alias in aliases:
        n = re.escape(alias).replace(r"\ ", r"\s+")
        if re.search(rf"(?<!\w){n}\s*(?:[:(—–-]\s*)?{re.escape(label)}(?:\b|$)", context, re.I):
            return True
    return False


def _attached_mentions(profile: Candidate, aliases: list[str]) -> list[dict]:
    """Resolve only explicit 'Full Name: @handle' mentions on known platforms."""
    templates = {"instagram": "https://instagram.com/{}", "x": "https://x.com/{}",
                 "telegram": "https://t.me/{}", "tiktok": "https://tiktok.com/@{}",
                 "vk": "https://vk.com/{}", "github": "https://github.com/{}"}
    template = templates.get(profile.platform)
    if not template:
        return []
    out: list[dict] = []
    for alias in aliases:
        pattern = re.compile(rf"\b{re.escape(alias)}\s*(?:[:(—–-]\s*)?@([A-Za-z0-9_.-]{{2,40}})\b", re.I)
        for match in pattern.finditer(profile.public_text):
            out.append({"url": template.format(match.group(1)), "site": profile.platform,
                        "anchor": alias, "context": match.group(0), "source_url": profile.url,
                        "kind": "name_attached_mention"})
    return out[:20]


def discover_via_related(name: str, backend, *, client: PoliteClient | None = None,
                         max_people: int = 2, read_pages: int = 2,
                         sources: list[tuple[str, str]] | None = None,
                         variants: list[str] | None = None) -> dict:
    """Find associates and make at most one bounded public-page hop.

    Supplied source text is reused. If it has no co-mentions, try two alias
    searches and at most ``read_pages`` public source documents. Another total
    ``read_pages`` associate profiles may be read; no recursive crawling.
    """
    out: dict = {"people": [], "candidates": [], "errors": [], "evidence": [],
                 "stats": {"related_queries": 0, "related_source_pages_read": 0,
                           "related_profile_pages_read": 0, "related_people_count": 0,
                           "related_accounts_found": 0, "via_related_found": 0,
                           "related_source_pages_ok": 0, "related_profile_pages_ok": 0}}
    own = client is None
    client = client or PoliteClient()
    max_people = min(5, max(0, max_people))
    read_pages = min(6, max(0, read_pages))
    aliases = _aliases(name, variants)
    collected = list(sources or [])[:40]
    by_key: dict[str, Candidate] = {}

    def _search(query: str, limit: int) -> list[SearchResult]:
        out["stats"]["related_queries"] += 1
        try:
            hits = backend.search(query, max_results=limit) or []
            for hit in hits:
                if not hit.query:
                    hit.query = query
                if not hit.provider:
                    hit.provider = getattr(backend, "last_used", "") or getattr(backend, "name", "")
            return hits
        except Exception as exc:
            out["errors"].append(f"related search: {exc!r}")
            return []

    def _add(c: Candidate, person: dict, relation: str, evidence: dict) -> Candidate:
        c.related_person = person["name"]
        c.relation = relation
        c.name_match = relation == "via_related"
        for ev in [*person["evidence"], evidence]:
            if ev not in c.evidence:
                c.evidence.append(dict(ev))
        reason = ("target_owner_via_related_search" if evidence["kind"] == "joint_profile_search"
                  else "explicit_target_link_via_related") if relation == "via_related" else "co_mentioned_person_account"
        if reason not in c.match_reasons:
            c.match_reasons.append(reason)
        key = canonical_candidate_key(c)
        if key in by_key:
            existing = by_key[key]
            merge_candidate(existing, c)
            # Evidence from the stronger chain may upgrade a weak lead, but a
            # subsequent associate search must not demote a target proposal.
            if relation == "via_related":
                existing.relation = relation
                existing.name_match = True
            return existing
        by_key[key] = c
        out["candidates"].append(c)
        return c

    try:
        people = nearby_people(name, collected, max_people, variants=aliases)
        if not people:
            hits: list[SearchResult] = []
            seen_urls = {url for url, _ in collected}
            for alias in aliases[:2]:
                hits.extend(_search(f'"{alias}"', 12))
            for hit in hits:
                collected.append((hit.url, f"{hit.title}\n{hit.snippet}"))
            for hit in hits:
                if out["stats"]["related_source_pages_read"] >= read_pages:
                    break
                if hit.url in seen_urls:
                    continue
                seen_urls.add(hit.url)
                c = Candidate(platform="web", url=hit.url, title=hit.title, snippet=hit.snippet)
                out["stats"]["related_source_pages_read"] += 1
                try:
                    enrich_candidate(c, client)
                    if c.fetch_status == "ok":
                        out["stats"]["related_source_pages_ok"] += 1
                    elif c.fetch_status == "error":
                        out["errors"].append(f"related reader: {c.fetch_error}")
                    if c.public_text:
                        collected.append((hit.url, c.public_text))
                except Exception as exc:
                    out["errors"].append(f"related reader: {exc!r}")
            people = nearby_people(name, collected, max_people, variants=aliases)
        out["people"] = [p["name"] for p in people]
        out["stats"]["related_people_count"] = len(people)
        out["evidence"] = [ev for p in people for ev in p["evidence"]]
        if not people:
            out["errors"].append("[info] Рядом с именем не найдены другие люди в доступном тексте.")
            return out

        profile_queue: list[tuple[Candidate, dict, bool]] = []
        for person in people:
            pname = person["name"]
            associate_keys: set[str] = set()
            queries = [*build_queries(pname, {}), ("extra", build_extra_query(pname))]
            for platform, query in queries:
                phits = _search(query, 6)
                platforms = PLATFORMS if platform == "extra" else (platform,)
                for site in platforms:
                    for c in classify(pname, {}, site, phits):
                        strong_associate = c.name_match
                        if strong_associate:
                            associate_keys.add(canonical_candidate_key(c))
                        evidence = {"kind": "associate_profile_search", "source_url": c.url,
                                    "excerpt": f"{c.title} {c.snippet}".strip()[:600],
                                    "query": query, "provider": next((h.provider for h in phits if h.url == c.url), ""),
                                    "related_person": pname}
                        saved = _add(c, person, "related_person", evidence)
                        profile_queue.append((saved, person, strong_associate))
            query = f'"{name}" "{pname}" ({" OR ".join(_SOCIAL_SITES)})'
            for hit in _search(query, 8):
                for alias in aliases:
                    for site in PLATFORMS:
                        for c in classify(alias, {}, site, [hit]):
                            # A target mention in an associate's snippet is not
                            # evidence that the associate profile belongs to it.
                            owner_hit = SearchResult(hit.url, hit.title, "")
                            target_owner = is_name_match(alias, owner_hit, c.handle)
                            via = target_owner and canonical_candidate_key(c) not in associate_keys
                            ev = {"kind": "joint_profile_search", "source_url": hit.url,
                                  "excerpt": f"{hit.title} {hit.snippet}".strip()[:600],
                                  "query": query, "provider": hit.provider, "related_person": pname}
                            _add(c, person, "via_related" if via else "related_person", ev)

        seen_profiles: set[str] = set()
        # Strong associate-owner hits are a better starting point than arbitrary
        # profile URLs returned for that person's name. Preserve both in output.
        profile_queue.sort(key=lambda item: (item[2], item[0].score), reverse=True)
        for profile, person, _ in profile_queue:
            if out["stats"]["related_profile_pages_read"] >= read_pages:
                break
            key = canonical_candidate_key(profile)
            if key in seen_profiles or profile.relation == "via_related":
                continue
            seen_profiles.add(key)
            out["stats"]["related_profile_pages_read"] += 1
            try:
                enrich_candidate(profile, client)
                if profile.fetch_status == "ok":
                    out["stats"]["related_profile_pages_ok"] += 1
                elif profile.fetch_status == "error":
                    out["errors"].append(f"related profile reader: {profile.fetch_error}")
            except Exception as exc:
                out["errors"].append(f"related profile reader: {exc!r}")
                continue
            links = [*profile.public_links, *_attached_mentions(profile, aliases)]
            for link in links:
                if (link.get("boilerplate") or link.get("site") not in PLATFORMS
                        or not _link_names_target(link, aliases)):
                    continue
                hit = SearchResult(link["url"], name, link.get("context", ""),
                                   provider="public_page", query="")
                for c in classify(name, {}, link["site"], [hit]):
                    if canonical_candidate_key(c) == key:
                        continue
                    ev = {"kind": link.get("kind", "name_attached_profile_link"),
                          "source_url": profile.url, "excerpt": link.get("context", "")[:600],
                          "target_url": c.url, "query": "", "provider": "public_page",
                          "related_person": person["name"]}
                    c.evidence.extend(ev for ev in profile.evidence if ev not in c.evidence)
                    _add(c, person, "via_related", ev)

        out["candidates"].sort(key=lambda c: (c.name_match, c.score), reverse=True)
        out["stats"]["via_related_found"] = sum(c.relation == "via_related" for c in out["candidates"])
        out["stats"]["related_accounts_found"] = sum(c.relation == "related_person" for c in out["candidates"])
        return out
    finally:
        if own:
            client.close()
