"""Orchestrate discovery: name + hints -> candidates -> (confirm) -> enrich."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import time
from urllib.parse import urlparse

from ..models import Profile
from .candidates import (
    PLATFORMS, SITE_FRAG, build_extra_query, build_queries, classify,
    canonical_candidate_key, merge_candidate, is_name_match,
    _handle_from_url,
)
from .enrich import enrich_candidate
from .http import PoliteClient
from .models import Candidate, DiscoveryResult, SearchResult
from .retrieval import SearchRun
from .search import SearchBackend, default_backend
from .translit import name_variants

# How many search queries run concurrently. Rare names walk the full backend
# fallback chain (Serper -> CSE -> SearXNG -> DDG) per query, ~10-15s each;
# fanning them out turns a sum into a max and cuts a 2-minute run to seconds.
# The whole batch (all variants at once) shares this pool, so a Cyrillic second
# variant adds queries but little wall-clock. Serper/SearXNG tolerate this fan-out.
_SEARCH_WORKERS = 8
_EXTRA_SITE_QUERIES = {'x': '(site:x.com OR site:twitter.com)', 'github': 'site:github.com',
                       'telegram': 'site:t.me', 'tiktok': 'site:tiktok.com', 'youtube': 'site:youtube.com'}


# People-search aggregators (spam) and non-profile post URLs are noise in the
# info feed — they don't help identify the person.
_JUNK_HOSTS = ("socialcatfish", "spokeo", "whitepages", "beenverified", "thatsthem",
               "radaris", "mylife", "peoplefinder", "truepeoplesearch", "intelius",
               "fastpeoplesearch", "idcrawl", "clustrmaps", "usersearch", "peekyou",
               "zabasearch", "instantcheckmate", "peoplelooker", "spydialer")
_JUNK_PATHS = ("/video/", "/status/", "/reel/", "/reels/", "/p/", "/photo/", "/posts/")


def _is_junk_info(url: str) -> bool:
    u = url.lower()
    return any(h in u for h in _JUNK_HOSTS) or any(p in u for p in _JUNK_PATHS)


def _linked_candidates(name: str, variants: list[str], hints: dict,
                       page: Candidate, *, owner: Candidate | None = None) -> list[Candidate]:
    """Keep explicit account links with their local context, without claiming ownership."""
    from .related import _link_names_target
    out = []
    for link in page.public_links:
        platform = link.get('site', '')
        if platform not in PLATFORMS or link.get('boilerplate'):
            continue
        anchor = link.get('anchor') or link.get('text', '')
        context = link.get('context', '')
        # A generic footer link on a news site is not evidence about the target.
        attached = _link_names_target(link, variants)
        declared = bool(link.get('rel_me'))
        owner_named = owner is not None and owner.name_match
        page_named = any(is_name_match(v, SearchResult(page.url, page.title, ''), '')
                         for v in variants)
        if not (attached or declared and (owner_named or page_named)):
            continue
        # Context stays in the snippet; names mentioned there are not the owner title.
        hit = SearchResult(link['url'], anchor, context)
        for c in classify(name, hints, platform, [hit]):
            if attached or declared and owner_named:
                c.name_match = True
                c.score = max(c.score, 0.65 if declared and owner_named else 0.55)
            c.note = 'Явная ссылка со страницы' + (' · rel=me' if declared else '')
            c.evidence = [{'kind': 'profile_link' if owner else 'page_link',
                           'source_url': page.url, 'excerpt': (context or anchor or page.title)[:500],
                           'target_url': c.url, 'rel_me': declared}]
            c.match_reasons.append('Явная ссылка рядом с именем' if attached else 'Ссылка rel=me')
            out.append(c)
    return out


def discover(
    name: str,
    hints: dict | None = None,
    platforms: tuple[str, ...] = PLATFORMS,
    backend: SearchBackend | None = None,
    max_per_platform: int = 10,
    username_scan: bool = True,
    max_scan_handles: int = 2,
    fetch_pages: int = 4,
    enrich_profiles: int = 2,
    related_search: str = "auto",
) -> DiscoveryResult:
    """Find candidate profiles for `name`. Network-bound; never raises.

    Results are ranked but UNCONFIRMED — a human should pick the real target
    before the data is used to build a password profile.
    """
    if related_search not in ('auto', 'always', 'off'):
        raise ValueError('related_search must be auto, always or off')
    started = time.monotonic()
    hints = hints or {}
    client = PoliteClient(min_interval=0.3, timeout=8, max_retries=1)
    search_client: PoliteClient | None = None
    if backend is None:
        # Search engines tolerate a brisker cadence than page scraping. Concurrency
        # + a tighter interval is the speed win; keep timeout/retries generous
        # enough that a transient failure doesn't silently drop a query's results
        # (recall matters more than shaving the last few seconds). DuckDuckGo caps
        # its own wait (it's usually gated) so it can't dominate the run.
        search_client = PoliteClient(min_interval=0.3, timeout=15, max_retries=2)
        backend = default_backend(search_client)
    backend = SearchRun(backend)
    result = DiscoveryResult(query_name=name, hints=hints)
    result.stats = {'source_pages_read': 0, 'profile_pages_read': 0,
                    'source_pages_ok': 0, 'profile_pages_ok': 0, 'page_errors': 0}

    if hasattr(backend, "is_available") and not backend.is_available():
        result.errors.append(
            "no search backend available — set SERPER_API_KEY / GOOGLE_CSE_KEY"
            " / SEARXNG_URL, install Playwright, or rely on the free scraper"
        )

    # A Cyrillic name is usually written in Latin on the web too — search both.
    variants = name_variants(name)

    try:
        seen: dict[str, Candidate] = {}
        info_seen: dict[str, dict] = {}

        def _keep(cands: list[Candidate]) -> None:
            for c in cands:
                key = canonical_candidate_key(c)
                if key in seen:
                    merge_candidate(seen[key], c)
                    continue
                seen[key] = c
                result.candidates.append(c)

        def _run_searches(tasks: list[dict], max_results: int) -> list[dict]:
            """Fan a batch of search tasks out across threads.

            Each task is a dict with a "query" (run in a worker) plus whatever
            aggregation context the caller needs ("tag", "platform", "variant").
            Only the network call runs off the main thread; results are returned
            so classify/aggregate stays single-threaded and race-free. Order is
            preserved for deterministic aggregation.
            """
            if not tasks:
                return []
            with ThreadPoolExecutor(max_workers=min(_SEARCH_WORKERS, len(tasks))) as ex:
                futs = []
                for task in tasks:
                    if task['tag'] == 'site' and task['platform']:
                        future = ex.submit(backend.search_profiles, task['query'], max_results=max_results,
                                           platform=task['platform'], name=task['variant'])
                    else:
                        future = ex.submit(backend.search, task['query'], max_results=max_results)
                    futs.append((task, future))
                out = []
                for t, fut in futs:
                    try:
                        out.append({**t, "hits": fut.result(), "err": None})
                    except Exception as e:  # noqa: BLE001 — one query mustn't kill the run
                        out.append({**t, "hits": [], "err": repr(e)})
                return out

        def _absorb_web_info(hits, *, skip_urls: set[str] | None = None) -> None:
            skip_urls = skip_urls or set()
            for h in hits:
                host = (urlparse(h.url).hostname or '').lower()
                if (h.url in skip_urls or not h.url.startswith("http")
                        or any(host == bad + '.com' or host.endswith('.' + bad + '.com')
                               for bad in _JUNK_HOSTS)):
                    continue
                # Raw www/tracking aliases of profiles must not consume source
                # slots intended for publications, websites and public posts.
                if any(_handle_from_url(p, h.url) for p in PLATFORMS):
                    continue
                key = h.url.split("#")[0].rstrip("/").lower()
                if key in info_seen:
                    source = info_seen[key]
                    for field in ('title', 'snippet'):
                        text = getattr(h, field)
                        if text and text not in source[field]:
                            source[field] = (source[field] + '\n' + text).strip()[:4000]
                    continue
                if len(result.web_info) >= 100:
                    continue
                info_seen[key] = {"url": h.url, "title": h.title,
                                  "snippet": h.snippet, 'query': h.query, 'provider': h.provider}
                result.web_info.append(info_seen[key])

        # Build ONE query batch across every name variant and run it in a single
        # concurrent wave — so a second variant (e.g. the Cyrillic form of a
        # Latin-typed name) costs almost no extra wall-clock, not a doubling.
        #   1) site-scoped dorks (precise per-platform profile hits)
        #   2) a plain "name" query (nickname handles + corroborating pages)
        #   3) one combined dork sweeping X / GitHub / Telegram / TikTok / YT
        tasks: list[dict] = []
        for variant in variants:
            for platform, query in build_queries(variant, hints):
                if platform in platforms:
                    tasks.append({"tag": "site", "platform": platform,
                                  "query": query, "variant": variant})
            tasks.append({"tag": "web", "platform": None,
                          "query": f'"{variant}"', "variant": variant})
            tasks.append({"tag": "extra", "platform": None,
                          "query": build_extra_query(variant), "variant": variant})

        for r in _run_searches(tasks, max_per_platform * 2):
            variant, hits = r["variant"], r["hits"]
            if r["err"]:
                result.errors.append(f"{r['platform'] or r['tag']}: {r['err']}")
                continue
            if r["tag"] == "site":
                _keep(classify(variant, hints, r["platform"], hits))
                _absorb_web_info(hits)
            elif r["tag"] == "web":
                social_urls: set[str] = set()
                for p in platforms:
                    for c in classify(variant, hints, p, hits):
                        social_urls.add(c.url)
                        _keep([c])
                _absorb_web_info(hits, skip_urls=social_urls)
            elif r["tag"] == "extra":
                for p in platforms:
                    _keep(classify(variant, hints, p, hits))
                _absorb_web_info(hits)

        # ESCALATION — only when few direct accounts were found, so the common
        # case stays lean. Two things happen here:
        #  a) PLAIN (unquoted) queries. A quoted `site:` dork often returns 0 for
        #     gated networks (LinkedIn especially — search engines index it
        #     sparsely), yet the SAME name without quotes / with a plain keyword
        #     returns the profile. So we also "just look with an ordinary query".
        #  b) Community/hub pages (KZ tech + hackathons + GitHub-by-name) that tie
        #     a real NAME to a person's accounts, read later for cross-links.
        esc: list[dict] = []
        if not any(c.name_match for c in result.candidates):
            for variant in variants:
                # the plain "ordinary query" — no quotes, no site: filter
                esc.append({"tag": "plain", "platform": None,
                            "query": variant, "variant": variant})
                # unquoted sweep of the remaining networks by name
                esc.append({"tag": "extra", "platform": None,
                            "query": build_extra_query(variant).replace('"', ""),
                            "variant": variant})
            for hq in (f'site:astanahub.com "{name}"',
                       f'(site:devpost.com OR site:dorahacks.io) "{name}"',
                       f'site:github.com "{name}"'):
                esc.append({"tag": "hub", "platform": None, "query": hq, "variant": name})

        # Coverage is platform-specific: a GitHub/Instagram match must not stop
        # LinkedIn (or another primary network) from trying an unquoted query.
        covered = {c.platform for c in result.candidates if c.name_match}
        recovery_counts = {platform: 0 for platform in platforms}
        for platform, fragment in SITE_FRAG.items():
            if platform in platforms and platform not in covered:
                for variant in variants[:3]:
                    esc.append({'tag': 'site', 'platform': platform,
                                'query': f'{fragment} {variant}', 'variant': variant})
                    recovery_counts[platform] += 1

        # A combined OR query may contain hits from only one network. Explicitly
        # query uncovered platforms once; unrelated accounts must not stop discovery.
        covered = {c.platform for c in result.candidates if c.name_match}
        for platform, fragment in _EXTRA_SITE_QUERIES.items():
            if platform in platforms and platform not in covered:
                esc.append({'tag': 'site', 'platform': platform,
                            'query': f'{fragment} "{name}"', 'variant': name})

        for r in _run_searches(esc, max_per_platform * 2):
            if r["err"]:
                result.errors.append(f"{r['tag']}: {r['err']}")
                continue
            hh, variant = r["hits"], r["variant"]
            if r["tag"] == "site":
                _keep(classify(variant, hints, r["platform"], hh))
            else:                       # plain / extra / hub -> try every platform
                for platform in platforms:
                    _keep(classify(variant, hints, platform, hh))
            _absorb_web_info(hh)

        # LinkedIn exact-phrase /in/ searches can miss reordered names and legacy
        # /pub/ or regional results. Relax in bounded waves, stopping as soon as
        # a named profile is retrieved. No URLs are guessed from a person's name.
        if 'linkedin' in platforms:
            for template in ('site:linkedin.com {name}', '{name} LinkedIn'):
                if any(c.platform == 'linkedin' and c.name_match for c in result.candidates):
                    break
                li_tasks = [{'tag': 'site', 'platform': 'linkedin', 'variant': variant,
                             'query': template.format(name=variant)} for variant in variants[:3]]
                recovery_counts['linkedin'] += len(li_tasks)
                for r in _run_searches(li_tasks, max_per_platform * 2):
                    if r['err']:
                        result.errors.append(f"linkedin recovery: {r['err']}")
                        continue
                    _keep(classify(r['variant'], hints, 'linkedin', r['hits']))
                    _absorb_web_info(r['hits'])
        result.stats['platform_recovery_queries'] = recovery_counts

        # Source pages are useful even when the search engine found NO account.
        # Prefer sources whose snippets name the target; keep the page budget explicit.
        social_domains = ('instagram.com', 'facebook.com', 'linkedin.com', 'vk.com',
                          'x.com', 'twitter.com', 'tiktok.com', 'youtube.com', 't.me')

        def _source_rank(web):
            host = (urlparse(web['url']).hostname or '').lower()
            social = any(host == d or host.endswith('.' + d) for d in social_domains)
            named = any(is_name_match(v, SearchResult(web['url'], web['title'], web['snippet']), '')
                        for v in variants)
            return not social, named

        ranked = sorted(result.web_info, key=_source_rank, reverse=True)
        # Reserve the front of the page budget for different hosts; indexed
        # reels from one gated network must not crowd out the open-web articles.
        hosts: dict[str, int] = {}
        diverse, deferred = [], []
        for web in ranked:
            host = urlparse(web['url']).hostname
            hosts[host] = hosts.get(host, 0) + 1
            (diverse if hosts[host] <= 2 else deferred).append(web)
        result.web_info = ranked_sources = (diverse + deferred)[:25]
        sources = [(w['url'], f"{w['title']}\n{w['snippet']}") for w in result.web_info]
        def _read_pages(pages: list[Candidate], metric: str):
            if not pages:
                return []
            with ThreadPoolExecutor(max_workers=min(3, len(pages))) as pool:
                futures = [(page, pool.submit(enrich_candidate, page, client)) for page in pages]
                read = []
                for page, future in futures:
                    try:
                        future.result()
                        result.stats[metric] += 1
                        if getattr(page, 'fetch_status', '') == 'ok':
                            result.stats[metric.replace('_read', '_ok')] += 1
                        if getattr(page, 'fetch_status', '') == 'error':
                            result.stats['page_errors'] += 1
                            result.errors.append(f"[page] {page.url}: {page.fetch_error}")
                        read.append(page)
                    except Exception as exc:
                        result.stats['page_errors'] += 1
                        result.errors.append(f"[page] {page.url}: {type(exc).__name__}")
                return read

        pages = [Candidate(platform='web', url=w['url'], title=w['title'], snippet=w['snippet'])
                 for w in ranked_sources[:max(0, min(fetch_pages, 8))]]
        by_url = {w['url']: w for w in result.web_info}
        for page in _read_pages(pages, 'source_pages_read'):
            if page.public_text:
                sources.append((page.url, page.public_text))
                # The manual continuation must retain late co-mentions too.
                by_url[page.url]['excerpt'] = page.public_text[:24000]
            _keep(_linked_candidates(name, variants, hints, page))

        # by-name finds lead, then by score — a direct name hit is never buried.
        result.candidates.sort(key=lambda c: (c.name_match, c.score), reverse=True)

        for c in _read_pages(list(result.candidates[:max(0, min(enrich_profiles, 4))]), 'profile_pages_read'):
            _keep(_linked_candidates(name, variants, hints, c, owner=c))

        # Account multiplier: pivot the best handles across other networks, so
        # one found account yields the person's other profiles. Bounded to the
        # top handles — good ranking puts the real person first, so this stays
        # on-target and cheap. This is the account-centric core of the OSINT.
        if username_scan and max_scan_handles > 0 and result.candidates:
            from .username import check_username, valid_handle
            scanned_urls = {c.url.rstrip("/").lower() for c in result.candidates}
            handles: list[str] = []
            hset: set[str] = set()
            for c in result.candidates:
                if not c.name_match:
                    continue
                h = valid_handle(c.handle)
                if h and h.lower() not in hset:
                    hset.add(h.lower())
                    handles.append(h)
                if len(handles) >= max_scan_handles:
                    break
            for h in handles:
                try:
                    for a in check_username(h):
                        key = a["url"].rstrip("/").lower()
                        if key in scanned_urls:
                            continue
                        scanned_urls.add(key)
                        _keep([Candidate(
                            platform=a["site"], url=a["url"], handle=h,
                            score=0.25, expanded_from=h, note=a.get("note", ""),
                            relation='username', match_reasons=['Совпадает ник; владелец не подтверждён'],
                            evidence=[{'kind': 'username', 'source_url': a['url'], 'excerpt': h}])])
                except Exception as e:  # noqa: BLE001 — never kill the run
                    result.errors.append(f"expand {h}: {e!r}")

        # Requirement 2: if the target's own accounts weren't found, reach them
        # via people mentioned nearby and propose accounts from their networks.
        if related_search == 'always' or (related_search == 'auto' and not any(
                c.name_match and c.relation != 'username' for c in result.candidates)):
            from .related import discover_via_related
            result.related_searched = True
            rel = discover_via_related(name, backend, client=client, sources=sources, variants=variants)
            result.related_people = rel["people"]
            result.related_evidence = rel.get('evidence', [])
            result.stats.update(rel.get('stats', {}))
            # A hit reached via a nearby person can STILL carry the target's own
            # name — that's a real by-name find, not an associate. Promote those
            # to primary candidates so they're never hidden in the "related"
            # bucket; only genuine associate accounts stay separate.
            for c in rel["candidates"]:
                if c.relation == 'via_related':
                    _keep([c])
                else:
                    result.related_accounts.append(c)
            result.candidates.sort(key=lambda c: (c.name_match, c.score),
                                   reverse=True)
            result.errors.extend(rel["errors"])

        # Namesake disambiguation: group same-identity accounts and record which
        # hints each hit matches, so the analyst can separate people who share
        # the name. Grouping never drops a candidate — recall is preserved.
        from .identity import annotate_identity
        n_groups = annotate_identity(name, hints, result.candidates)
        if n_groups > 1:
            result.errors.append(
                f"[info] Гипотез группировки аккаунтов: {n_groups}. "
                f"Общий ник не подтверждает одного владельца; уточните город/работодателя.")

        result.candidates.sort(key=lambda c: (c.name_match, c.score), reverse=True)
        result.stats.update(backend.stats())
        result.stats.update(candidate_count=len(result.candidates),
                            related_searched=result.related_searched,
                            with_evidence=sum(bool(c.evidence) for c in result.candidates),
                            seconds=round(time.monotonic() - started, 3))
        if 'linkedin' in platforms:
            li_candidates = [c for c in result.candidates if c.platform == 'linkedin']
            li_named = sum(c.name_match for c in li_candidates)
            result.stats.update(linkedin_candidates=len(li_candidates), linkedin_name_matches=li_named,
                                linkedin_recovery_queries=recovery_counts['linkedin'])
            if not li_named:
                result.errors.append('[info] LinkedIn: профиль с совпадением имени в доступной выдаче '
                                     'не найден. Это не означает, что аккаунта нет; '
                                     'остальные ссылки остаются неподтверждёнными предложениями.')
        for e in getattr(backend, "errors", []):
            result.errors.append(f"[backend] {e}")
    finally:
        client.close()
        if search_client is not None:
            search_client.close()
    return result


def enrich(
    candidates: list[Candidate],
    client: PoliteClient | None = None,
) -> list[Candidate]:
    """Fetch public text for each (confirmed) candidate. Network-bound."""
    own = client is None
    client = client or PoliteClient()
    try:
        return [enrich_candidate(c, client) for c in candidates]
    finally:
        if own:
            client.close()


def discover_related(name: str, hints: dict | None = None,
                     web_info: list[dict] | None = None) -> DiscoveryResult:
    """Explicit continuation after the user rejected the direct suggestions."""
    from .related import discover_via_related
    started = time.monotonic()
    result = DiscoveryResult(query_name=name, hints=hints or {}, related_searched=True)
    result.web_info = (web_info or [])[:25]
    sources = [(w['url'], '\n'.join(str(w.get(k, ''))[:24000]
                                    for k in ('title', 'snippet', 'excerpt')))
               for w in result.web_info if w.get('url')]
    with PoliteClient(min_interval=0.3, timeout=15, max_retries=2) as search_client, \
            PoliteClient(min_interval=0.3, timeout=8, max_retries=1) as page_client:
        backend = SearchRun(default_backend(search_client))
        related = discover_via_related(name, backend, client=page_client,
                                       sources=sources, variants=name_variants(name))
        result.related_people = related['people']
        result.related_evidence = related.get('evidence', [])
        result.errors = related['errors'] + [f'[backend] {e}' for e in backend.errors]
        for candidate in related['candidates']:
            destination = result.candidates if candidate.relation == 'via_related' else result.related_accounts
            destination.append(candidate)
        from .identity import annotate_identity
        annotate_identity(name, hints or {}, result.candidates)
        result.candidates.sort(key=lambda c: (c.name_match, c.score), reverse=True)
        result.stats = {**related.get('stats', {}), **backend.stats(), 'related_searched': True,
                        'seconds': round(time.monotonic() - started, 3)}
    return result


def candidates_to_profile(
    name: str,
    candidates: list[Candidate],
    hints: dict | None = None,
) -> Profile:
    """Fold enriched candidates into a Profile for the offline engine.

    Names/hints go to their structured fields; harvested keywords land in
    `custom` (later refined by the NER layer into interests/pets/etc.).
    """
    hints = hints or {}
    parts = name.split()
    profile = Profile(
        first_name=parts[0] if parts else "",
        last_name=parts[-1] if len(parts) > 1 else "",
        city=hints.get("city", ""),
        country=hints.get("country", ""),
        employer=hints.get("employer", ""),
        job_title=hints.get("job_title", ""),
    )
    kw: list[str] = []
    seen: set[str] = set()
    for c in candidates:
        if c.handle and c.handle.lower() not in seen:
            seen.add(c.handle.lower())
            kw.append(c.handle)
        for k in c.keywords:
            if k.lower() not in seen:
                seen.add(k.lower())
                kw.append(k)
    profile.custom = kw
    return profile
