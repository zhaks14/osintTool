"""Build platform dork queries and classify search hits into candidates."""

from __future__ import annotations

import json
import re
import unicodedata
import urllib.parse

from .models import Candidate, SearchResult

# Platforms we RECOGNISE in any result (classification). The primary scan only
# builds dedicated dorks for a subset (SITE_FRAG); the rest are caught from the
# open-web query and from username pivoting — so more networks, few extra queries.
PLATFORMS = ("linkedin", "instagram", "facebook", "vk", "x", "github",
             "telegram", "tiktok", "youtube")

_HOSTS = {
    "linkedin": ("linkedin.com",),
    "instagram": ("instagram.com",),
    "facebook": ("facebook.com", "fb.com"),
    "vk": ("vk.com", "vk.ru"),
    "x": ("x.com", "twitter.com"),
    "github": ("github.com",),
    "telegram": ("t.me", "telegram.me"),
    "tiktok": ("tiktok.com",),
    "youtube": ("youtube.com",),
}

# Non-profile paths to reject per platform (posts, help pages, etc.)
_REJECT_PATHS = {
    "linkedin": ("/feed", "/jobs", "/company", "/school", "/pulse", "/posts",
                 "/learning", "/help", "/legal"),
    "instagram": ("/p/", "/reel/", "/reels/", "/explore", "/stories",
                  "/accounts", "/about", "/directory"),
    "facebook": ("/watch", "/marketplace", "/groups", "/events", "/help",
                 "/pages", "/photo", "/story", "/permalink", "/sharer"),
    "vk": ("/wall", "/video", "/photo", "/topic", "/album", "/feed", "/im",
           "/audio", "/market", "/board"),
    "x": ("/i/", "/hashtag/", "/search", "/home", "/explore", "/notifications",
          "/messages", "/settings", "/intent", "/share", "/tos", "/privacy"),
    "github": ("/orgs/", "/apps/", "/sponsors/", "/topics/", "/collections/",
               "/marketplace", "/notifications", "/settings", "/pulls", "/issues"),
    "telegram": ("/s/", "/joinchat", "/addstickers", "/proxy", "/socks", "/iv",
                 "/share", "/setlanguage", "/+"),
    "tiktok": ("/tag/", "/music/", "/discover", "/foryou", "/following", "/live"),
    "youtube": ("/watch", "/results", "/feed", "/playlist", "/shorts", "/hashtag"),
}

# Reserved handles that are never a person's profile.
_RESERVED = {
    "instagram": {"explore", "accounts", "directory", "about", "developer",
                  "legal", "privacy", "reel", "reels", "p", "tv", "stories",
                  "help", "web", "emails", "session"},
    "facebook": {"profile.php", "people", "public", "pages", "groups",
                 "watch", "marketplace", "help", "login", "sharer", "gaming",
                 "find-friends", "findfriends", "friends", "home", "events",
                 "story.php", "photo.php", "bookmarks", "settings", "policies",
                 "business", "ads", "recover", "reg", "r.php", "l.php",
                 "login.php", "logout.php", "sharer.php", "share.php",
                 "permalink.php", "index.php", "home.php", "share", "dialog",
                 "plugins", "checkpoint", "connect", "search", "privacy", "terms"},
    "linkedin": set(),
    "vk": {"feed", "im", "audios", "video", "photos", "groups", "market",
           "apps", "login", "away", "settings", "id0"},
    "x": {"home", "explore", "search", "notifications", "messages", "settings",
          "i", "intent", "login", "signup", "tos", "privacy", "about", "hashtag"},
    "github": {"features", "about", "pricing", "login", "join", "marketplace",
               "explore", "topics", "trending", "settings", "sponsors",
               "notifications", "new", "orgs", "apps", "security", "dashboard",
               "pulls", "issues", "codespaces", "collections", "readme"},
    "telegram": {"s", "joinchat", "addstickers", "proxy", "socks", "iv",
                 "share", "setlanguage", "addemoji", "addlist", "addstyle",
                 "addtheme", "auction", "auth", "boost", "call", "confirmphone",
                 "contact", "giftcode", "invoice", "login", "m", "nft", "web",
                 "a", "k", "z", "oauth", "msg", "c", "newbot"},
    "tiktok": {"foryou", "following", "live", "discover", "tag", "music"},
    "youtube": {"watch", "results", "feed", "playlist", "shorts", "hashtag",
                "channel", "c", "user"},
}

# The subset we build dedicated `site:` dorks for. The four big people-networks
# get their own precise query (best recall + a hint-scoped variant); the rest are
# swept in ONE combined OR-dork below, so every platform is searched by name
# without exploding the query count (fewer queries = fewer rate-limit misses).
SITE_FRAG = {
    "linkedin": "site:linkedin.com/in",
    "instagram": "site:instagram.com",
    "facebook": "site:facebook.com",
    "vk": "(site:vk.com OR site:vk.ru)",
}

# Swept together in a single dork per name variant. These platforms rarely need
# hint-scoping (handles are unique) and are cheap to catch in bulk.
_EXTRA_SITES = ("site:x.com", "site:twitter.com", "site:github.com",
                "site:t.me", "site:tiktok.com", "site:youtube.com")


def build_extra_query(name: str) -> str:
    """One combined dork that sweeps X / GitHub / Telegram / TikTok / YouTube by
    name, so those networks are searched directly (not only caught by accident)."""
    return f'"{name}" ({" OR ".join(_EXTRA_SITES)})'


def build_queries(name: str, hints: dict) -> list[tuple[str, str]]:
    """Return (platform, query) dork pairs for the given target.

    hints may include: city, country, employer, job_title, school.
    """
    context_terms = [
        hints.get("city"), hints.get("employer"),
        hints.get("job_title"), hints.get("school"), hints.get("country"),
    ]
    context = " ".join(f'"{t}"' for t in context_terms if t)

    queries: list[tuple[str, str]] = []
    for platform, frag in SITE_FRAG.items():
        base = f'{frag} "{name}"'
        queries.append((platform, base))                 # name-only: broad recall
        # Hints ADD a precise query, never replace the broad one — so a wrong
        # city/employer can't silently drop the real profile (recall is kept),
        # it only helps surface the right namesake. Ranking uses hints too.
        if context:
            queries.append((platform, f"{base} {context}"))
    return queries


def _handle_from_url(platform: str, url: str) -> str | None:
    """Extract the profile slug/username, or None if this isn't a profile URL."""
    if not isinstance(platform, str) or platform not in _HOSTS or not isinstance(url, str):
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower().removeprefix("www.")
    except ValueError:
        return None
    if parsed.scheme not in ("http", "https"):
        return None
    # Exact host or a real subdomain only — never a look-alike like
    # "myfacebook.com" (which the old endswith(host) check wrongly accepted).
    if not any(host == h or host.endswith("." + h) for h in _HOSTS[platform]):
        return None
    # GitHub's docs/support/gist hosts are separate services, not aliases of
    # github.com/<username>. Do not manufacture a main-site account from them.
    if platform == "github" and host != "github.com":
        return None

    if platform == "telegram" and host not in _HOSTS[platform]:
        # Telegram defines <username>.t.me as an alias of t.me/<username>.
        # A path on that alias refers to a post or another deep link, not a
        # different username that can be extracted from the first path segment.
        alias = host.removesuffix(".t.me") if host.endswith(".t.me") else ""
        if (parsed.path in ("", "/") and re.fullmatch(r"[a-z0-9_]{2,32}", alias)
                and alias not in _RESERVED["telegram"]):
            return alias
        return None

    path = urllib.parse.unquote(parsed.path).rstrip("/")
    parts = [p for p in path.split("/") if p]
    root = parts[0].lower() if parts else ""
    # Routes are complete path segments, not substrings of a valid username
    # such as explorer_aslan, aboutanna or myvideo. VK media IDs are an
    # exception: /wall123_456 and /video-123_456 encode the route in one segment.
    if root in {p.strip("/") for p in _REJECT_PATHS[platform]}:
        return None
    if platform == "vk" and re.match(r"^(?:wall|video|photo|topic|album|audio|market|board)-?\d", root):
        return None
    if platform == "telegram" and root.startswith("+"):
        return None

    if platform == "linkedin":
        # linkedin.com/in/<slug>
        if len(parts) >= 2 and parts[0].lower() == "in":
            return parts[1]
        # Legacy public profiles retain three hexadecimal ID components.
        # The name alone is not a unique account or an observed /in/ handle.
        if (len(parts) == 5 and root == "pub" and parts[1].lower() != "dir"
                and re.fullmatch(r"[\w.-]+", parts[1])
                and all(re.fullmatch(r"[0-9a-fA-F]+", p) for p in parts[2:])):
            return "/".join(parts[1:])
        return None

    # instagram.com/<user>  or  facebook.com/<user>
    if platform == "facebook" and root == "profile.php" and len(parts) == 1:
        qs = urllib.parse.parse_qs(parsed.query)
        ids = qs.get("id", [])
        return ids[0] if len(ids) == 1 and re.fullmatch(r"[0-9]+", ids[0]) else None
    # facebook.com/people/<Name-Slug>/<id>/  — a very common real-profile shape
    # that the single-segment rule below would otherwise drop (recall gap).
    if platform == "facebook" and root == "people":
        # Only the account ID in this exact route identifies the person. A
        # later numeric photo/post ID must never be substituted for it, and a
        # malformed ID is not evidence that the name slug is a vanity handle.
        return parts[2] if len(parts) == 3 and re.fullmatch(r"[0-9]+", parts[2]) else None

    # tiktok.com/@user  and  youtube.com/@user | /c|user|channel/<x>
    if platform == "tiktok":
        if len(parts) == 1 and parts[0].startswith("@"):
            h = parts[0][1:]
            return h if re.fullmatch(r"[A-Za-z0-9_.]{2,30}", h) else None
        return None
    if platform == "youtube":
        if len(parts) == 1 and parts[0].startswith("@"):
            h = parts[0][1:]
            # YouTube supports international letters/numbers and internal
            # _-.· separators; vowel/combining marks are part of these names.
            # Length limits depend on script (including one-character Han),
            # so recognize URL syntax rather than duplicate registration rules.
            # https://support.google.com/youtube/answer/11585688
            valid = (1 <= len(h) <= 40
                     and unicodedata.category(h[0])[0] in "LN"
                     and unicodedata.category(h[-1])[0] in "LNM"
                     and all(unicodedata.category(c)[0] in "LNM" or c in "_-.·" for c in h))
            return h if valid else None
        if len(parts) == 2 and parts[0].lower() in ("c", "user", "channel"):
            return parts[1] or None
        return None

    if len(parts) == 1:
        handle = parts[0]
        if handle.lower() in _RESERVED[platform]:
            return None
        if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,60}", handle):
            return None
        return handle
    return None


def canonical_profile_url(platform: str, url: str) -> str:
    """Normalize profile aliases/tracking without conflating distinct handles.

    YouTube's /channel/<id>, /user/<name> and /@<handle> are separate namespaces;
    an identical final segment does not establish that they are one account.
    """
    handle = _handle_from_url(platform, url)
    if not handle:
        return url.split("#", 1)[0].rstrip("/")
    if platform == "youtube":
        parts = [p for p in urllib.parse.urlparse(url).path.split("/") if p]
        namespace = parts[0].lower() if len(parts) == 2 else "@"
        slug = handle if namespace == "channel" else handle.casefold()
        slug = urllib.parse.quote(slug, safe="-._")
        path = f"/{namespace}/{slug}" if namespace != "@" else f"/@{slug}"
        return "https://youtube.com" + path
    if platform == "linkedin":
        parts = [p for p in urllib.parse.unquote(urllib.parse.urlparse(url).path).split("/") if p]
        namespace = parts[0].lower()
        handle = urllib.parse.quote(handle.casefold(), safe="-._/" if namespace == "pub" else "-._")
        return f"https://linkedin.com/{namespace}/{handle}"
    handle = urllib.parse.quote(handle.casefold(), safe="-._")
    if platform == "facebook" and handle.isdigit():
        return f"https://facebook.com/profile.php?id={handle}"
    prefix = "@" if platform == "tiktok" else ""
    return f"https://{_HOSTS[platform][0]}/{prefix}{handle}"


def canonical_candidate_key(candidate: Candidate) -> str:
    """Stable within-platform key; punctuation is significant in usernames."""
    if candidate.platform not in _HOSTS and candidate.url:
        return f"{candidate.platform}:{canonical_profile_url(candidate.platform, candidate.url)}"
    if _handle_from_url(candidate.platform, candidate.url):
        return f"{candidate.platform}:{canonical_profile_url(candidate.platform, candidate.url)}"
    return f"{candidate.platform}:{candidate.handle.casefold() or candidate.url}"


def _unique(items: list) -> list:
    seen: set[str] = set()
    out = []
    for item in items:
        key = json.dumps(item, sort_keys=True, ensure_ascii=False)
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def merge_candidate(existing: Candidate, incoming: Candidate) -> Candidate:
    """Merge retrieval evidence in place, retaining the strongest observed hit.

    Repeated search-engine copies are not independent ownership evidence, so
    duplicates never add a score bonus. Original excerpts remain in evidence.
    """
    if canonical_candidate_key(existing) != canonical_candidate_key(incoming):
        raise ValueError("Cannot merge different profile accounts")
    if incoming.name_match:
        if incoming.relation == "direct":
            existing.relation = "direct"
        elif incoming.relation == "via_related" and not existing.name_match:
            existing.relation = "via_related"
    if (incoming.name_match, incoming.score) > (existing.name_match, existing.score):
        existing.title = incoming.title or existing.title
        existing.snippet = incoming.snippet or existing.snippet
    else:
        existing.title = existing.title or incoming.title
        existing.snippet = existing.snippet or incoming.snippet
    existing.score = max(existing.score, incoming.score)
    existing.name_match = existing.name_match or incoming.name_match
    existing.confirmed = existing.confirmed or incoming.confirmed
    for field in ("evidence", "match_reasons", "matched_hints", "keywords", "public_links"):
        setattr(existing, field, _unique(getattr(existing, field) + getattr(incoming, field)))
    if len(incoming.public_text) > len(existing.public_text):
        existing.public_text = incoming.public_text
    existing.image_url = existing.image_url or incoming.image_url
    existing.related_person = existing.related_person or incoming.related_person
    existing.expanded_from = existing.expanded_from or incoming.expanded_from
    existing.note = existing.note or incoming.note
    # A later search snippet is not an unread overwrite of a successfully read
    # document. Prefer the best retained read result and its corresponding error.
    read_rank = {"not_read": 0, "error": 1, "empty": 2, "ok": 3}
    if read_rank.get(incoming.fetch_status, 0) > read_rank.get(existing.fetch_status, 0):
        existing.fetch_status = incoming.fetch_status
        existing.fetch_error = incoming.fetch_error
    existing.url = canonical_profile_url(existing.platform, existing.url)
    return existing


# snippet cues that mark the real, popular account over a namesake
_VERIFIED = ("verified", "official", "verifiziert", "verificad", "verificado",
             "проверен", "официальн")
_FOLLOWERS = re.compile(
    r"\d[\d.,]*\s*(?:m|k|mln|млн|тыс|тис)?\s*(?:followers|подписчик|subscribers)",
    re.I)


def _score(name: str, hints: dict, result: SearchResult, handle: str) -> float:
    """Retrieval ranking, not an identity probability or verification claim."""
    parts = _words(name)
    text = f"{result.title} {result.snippet}"
    words = set(_words(text))
    title_match = _title_name_matches(name, result.title, handle)
    handle_match = _handle_name_matches(name, handle)
    ratio = sum(p in words for p in parts) / len(parts) if parts else 0
    score = 0.58 if title_match else 0.18 * ratio
    if handle_match:
        score += 0.20 if title_match else 0.50
    # These are merely snippet claims and deliberately have little weight.
    if any(s in text.casefold() for s in _VERIFIED):
        score += 0.02
    if _FOLLOWERS.search(text):
        score += 0.01
    score += 0.06 * len(_matched_hints(hints, text))
    return round(min(score, 1.0), 4)


_WORD_RE = re.compile(r"[^\W_]+", re.UNICODE)


def _words(text: str) -> list[str]:
    # O'Neil / O’Neil and hyphenated names are consistently comparable, while
    # short names such as Li still require whole tokens, never substrings.
    text = unicodedata.normalize("NFKC", text or "").casefold()
    text = text.replace("'", "").replace("’", "")
    return _WORD_RE.findall(text)


def _title_name_matches(name: str, title: str, handle: str = "") -> bool:
    """Name at the start of the displayed owner field, not in a bio suffix."""
    parts = _words(name)
    if not parts:
        return False
    owner = re.split(r"\s[-–—|·•]\s|[|•·]|\s*\(@", title or "", maxsplit=1)[0]
    # GitHub displays the username before the owner's full name, e.g.
    # "torvalds (Linus Torvalds) · GitHub". Require that prefix to be the
    # actual URL handle and the parentheses to contain only the target name.
    bracketed = re.fullmatch(r"\s*([^\s()]+)\s*\(([^()]*)\)\s*", owner)
    if (bracketed and handle and bracketed[1].removeprefix("@").casefold() == handle.casefold()
            and _words(bracketed[2]) in (parts, list(reversed(parts)))):
        return True
    owner_parts = _words(owner)
    if owner_parts and owner_parts[0] in {"dr", "prof", "mr", "mrs", "ms"}:
        owner_parts = owner_parts[1:]
    return owner_parts[:len(parts)] in (parts, list(reversed(parts)))


def _handle_name_matches(name: str, handle: str) -> bool:
    parts = _words(name)
    handle_parts = _words(handle)
    if not parts or not handle_parts:
        return False
    compact = "".join(handle_parts)
    variants = {"".join(parts), "".join(reversed(parts))}
    if compact in variants or re.sub(r"\d+$", "", compact) in variants:
        return True
    # Token-separated names support surname-first, suffixes and short names;
    # fragments in e.g. climbingwang must never satisfy the name Li Wang.
    return len(parts) >= 2 and all(p in handle_parts for p in parts)


def _matched_hints(hints: dict, text: str) -> list[str]:
    normalized = " " + " ".join(_words(text)) + " "
    values = []
    for key in ("city", "employer", "job_title", "school", "country"):
        value = str(hints.get(key) or "").strip()
        if value and " " + " ".join(_words(value)) + " " in normalized:
            values.append(value)
    return list(dict.fromkeys(values))


def is_name_match(name: str, result: SearchResult, handle: str) -> bool:
    """Owner/title or full-name handle evidence; still not proven ownership.

    A target mentioned only in someone else's snippet remains a suggestion,
    but cannot alone stop the related-person fallback or become a direct find.
    """
    return _title_name_matches(name, result.title, handle) or _handle_name_matches(name, handle)


def classify(name: str, hints: dict, platform: str,
             results: list[SearchResult]) -> list[Candidate]:
    """Turn raw search results into scored, de-duplicated candidates.

    Every recognized profile remains a suggestion. Owner/title or full-name
    handle evidence is flagged `name_match`; a mere mention in somebody else's
    snippet stays weak. Scores order review and never establish ownership.
    """
    seen: dict[str, Candidate] = {}
    out: list[Candidate] = []
    for r in results:
        handle = _handle_from_url(platform, r.url)
        if not handle:
            continue
        nm = is_name_match(name, r, handle)
        score = _score(name, hints, r, handle)
        if nm:
            score = max(score, 0.5)
        reasons = ["profile_url"]
        if _title_name_matches(name, r.title, handle):
            reasons.append("name_in_title")
        if _handle_name_matches(name, handle):
            reasons.append("name_in_handle")
        parts = _words(name)
        text_words = set(_words(f"{r.title} {r.snippet}"))
        if parts and all(p in text_words for p in parts) and "name_in_title" not in reasons:
            reasons.append("name_mentioned")
        elif any(p in text_words for p in parts) and not nm:
            reasons.append("partial_name")
        matched_hints = _matched_hints(hints, f"{r.title} {r.snippet}")
        reasons.extend(f"hint:{value}" for value in matched_hints)
        candidate = Candidate(
            platform=platform,
            url=canonical_profile_url(platform, r.url),
            handle=handle,
            title=r.title,
            snippet=r.snippet,
            score=score,
            name_match=nm,
            matched_hints=matched_hints,
            match_reasons=reasons,
            evidence=[{"kind": "search_result", "source_url": r.url,
                       "excerpt": " — ".join(p for p in (r.title, r.snippet) if p),
                       "query": r.query, "provider": r.provider}],
        )
        key = canonical_candidate_key(candidate)
        if key in seen:
            merge_candidate(seen[key], candidate)
        else:
            seen[key] = candidate
            out.append(candidate)
    # name matches first, then by score — direct by-name finds lead the list.
    out.sort(key=lambda c: (c.name_match, c.score), reverse=True)
    return out
