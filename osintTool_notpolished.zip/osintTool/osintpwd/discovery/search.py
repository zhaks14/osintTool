"""Pluggable search backends with automatic fallback.

Priority (first available & non-empty wins):
    1. Serper.dev          (SERPER_API_KEY)          — reliable, keyed
    2. Google CSE JSON API (GOOGLE_CSE_KEY + _CX)    — reliable, keyed
    3. SearXNG             (SEARXNG_URL, self-host)  — free, private, no key
    4. Playwright/Bing     (optional dep)            — free, renders JS
    5. DuckDuckGo HTML     (scrape)                  — free, often gated

Each backend advertises `is_available()`. Generic searches stop at the first
nonempty provider; profile searches continue until a profile matches the target
name and platform, retaining partial results. A production deploy sets a key
(1/2) or runs SearXNG (3); the free scrapers are last-ditch.
"""

from __future__ import annotations

import base64
import binascii
import json
import threading
import time
import urllib.parse
from dataclasses import replace
from typing import Protocol, runtime_checkable

from bs4 import BeautifulSoup

from .config import DiscoveryConfig
from .http import PoliteClient
from .models import SearchResult


@runtime_checkable
class SearchBackend(Protocol):
    name: str

    def is_available(self) -> bool: ...
    def search(self, query: str, max_results: int = 20) -> list[SearchResult]: ...


# --------------------------------------------------------------------------- #
# Keyed backends
# --------------------------------------------------------------------------- #
class SerperBackend:
    name = "serper"
    URL = "https://google.serper.dev/search"

    def __init__(self, api_key: str, client: PoliteClient) -> None:
        self._key = api_key
        self._client = client

    def is_available(self) -> bool:
        return bool(self._key)

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        # Serper's free plan rejects num > 10 ("Query pattern not allowed for
        # free accounts"), so clamp it — a single page is plenty for discovery.
        num = min(max_results, 10)
        resp = self._client.post(
            self.URL,
            headers={"X-API-KEY": self._key, "Content-Type": "application/json"},
            content=json.dumps({"q": query, "num": num}),
        )
        if resp is None or resp.status_code != 200:
            raise RuntimeError(f"Serper request failed: HTTP {resp.status_code if resp is not None else 'unavailable'}")
        data = resp.json()
        out: list[SearchResult] = []
        for item in data.get("organic", [])[:max_results]:
            out.append(SearchResult(
                url=item.get("link", ""),
                title=item.get("title", ""),
                snippet=item.get("snippet", ""),
            ))
        return [r for r in out if r.url]


class GoogleCSEBackend:
    name = "google_cse"
    URL = "https://www.googleapis.com/customsearch/v1"

    def __init__(self, api_key: str, cx: str, client: PoliteClient) -> None:
        self._key = api_key
        self._cx = cx
        self._client = client

    def is_available(self) -> bool:
        return bool(self._key and self._cx)

    def search(self, query: str, max_results: int = 10) -> list[SearchResult]:
        # CSE returns max 10 per call; we take the first page.
        resp = self._client.get(self.URL, params={
            "key": self._key, "cx": self._cx, "q": query,
            "num": min(max_results, 10),
        })
        if resp is None or resp.status_code != 200:
            raise RuntimeError(f"Google CSE request failed: HTTP {resp.status_code if resp is not None else 'unavailable'}")
        data = resp.json()
        out: list[SearchResult] = []
        for item in data.get("items", [])[:max_results]:
            out.append(SearchResult(
                url=item.get("link", ""),
                title=item.get("title", ""),
                snippet=item.get("snippet", ""),
            ))
        return [r for r in out if r.url]


# --------------------------------------------------------------------------- #
# Self-hosted / free backends
# --------------------------------------------------------------------------- #
class SearxngBackend:
    name = "searxng"

    # Engines that tend to honour `site:` operators. Free engines rotate
    # through CAPTCHA/rate-limit, so we query a broad set and let SearXNG
    # merge whatever is currently alive. Override with OSINT_SEARXNG_ENGINES.
    DEFAULT_ENGINES = ("google,bing,duckduckgo,brave,startpage,mojeek,"
                       "presearch,mullvadleta,qwant")

    def __init__(self, base_url: str, client: PoliteClient) -> None:
        self._base = base_url.rstrip("/")
        self._client = client
        import os
        self._engines = os.environ.get("OSINT_SEARXNG_ENGINES",
                                       self.DEFAULT_ENGINES)

    def is_available(self) -> bool:
        return bool(self._base)

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        params = {"q": query, "format": "json", "safesearch": "0"}
        if self._engines:
            params["engines"] = self._engines
        resp = self._client.get(f"{self._base}/search", params=params)
        if resp is None or resp.status_code != 200:
            raise RuntimeError(f"SearXNG request failed: HTTP {resp.status_code if resp is not None else 'unavailable'}")
        try:
            data = resp.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise RuntimeError("SearXNG returned invalid JSON") from exc
        out: list[SearchResult] = []
        for item in data.get("results", [])[:max_results]:
            out.append(SearchResult(
                url=item.get("url", ""),
                title=item.get("title", ""),
                snippet=item.get("content", ""),
                provider="searxng" + (":" + str(item["engine"]) if item.get("engine") else ""),
            ))
        return [r for r in out if r.url]


def _decode_bing_redirect(url: str) -> str:
    """Bing wraps results as bing.com/ck/a?...&u=a1<base64url>. Unwrap it."""
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return url
    host = (parsed.hostname or '').lower()
    if not (host == 'bing.com' or host.endswith('.bing.com')) or parsed.path != '/ck/a':
        return url
    qs = urllib.parse.parse_qs(parsed.query)
    raw = qs.get("u", [""])[0]
    if raw.startswith(('https://', 'http://')):
        return raw
    if not raw.startswith('a1'):
        return url
    raw = raw[2:]
    raw += '=' * (-len(raw) % 4)
    try:
        target = base64.urlsafe_b64decode(raw).decode('utf-8')
        return target if target.startswith(('https://', 'http://')) else url
    except (binascii.Error, ValueError, UnicodeError):
        return url


class PlaywrightBackend:
    """Renders a real Bing results page with a headless browser.

    Optional: requires `pip install playwright` + `playwright install chromium`.
    Lazily imported so the rest of the tool works without it.
    """

    name = "playwright"

    def __init__(self) -> None:
        self._checked = False
        self._ok = False

    def is_available(self) -> bool:
        if self._checked:
            return self._ok
        self._checked = True
        try:
            import playwright  # noqa: F401
            self._ok = True
        except ImportError:
            self._ok = False
        return self._ok

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            return []

        url = "https://www.bing.com/search?q=" + urllib.parse.quote_plus(query)
        out: list[SearchResult] = []
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page(
                    user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                "AppleWebKit/537.36 (KHTML, like Gecko) "
                                "Chrome/124.0 Safari/537.36")
                )
                page.goto(url, wait_until="domcontentloaded", timeout=25000)
                page.wait_for_timeout(1500)
                html = page.content()
                browser.close()
        except Exception:  # noqa: BLE001 — browser failures are non-fatal
            return []

        soup = BeautifulSoup(html, "html.parser")
        for li in soup.select("li.b_algo")[:max_results]:
            a = li.select_one("h2 a")
            if not a or not a.get("href"):
                continue
            snip = li.select_one(".b_caption p")
            out.append(SearchResult(
                url=_decode_bing_redirect(a["href"]),
                title=a.get_text(" ", strip=True),
                snippet=snip.get_text(" ", strip=True) if snip else "",
            ))
        return out


def _unwrap_ddg(href: str) -> str:
    try:
        parsed = urllib.parse.urlparse(urllib.parse.urljoin('https://duckduckgo.com', href))
    except ValueError:
        return href
    host = (parsed.hostname or '').lower()
    if (host == 'duckduckgo.com' or host.endswith('.duckduckgo.com')) and parsed.path == '/l/':
        qs = urllib.parse.parse_qs(parsed.query)
        if "uddg" in qs:
            target = qs['uddg'][0]  # parse_qs has already decoded this layer.
            if target.startswith(('https://', 'http://')):
                return target
    if href.startswith("//"):
        return "https:" + href
    return href


class DuckDuckGoBackend:
    name = "duckduckgo"
    URL = "https://html.duckduckgo.com/html/"

    def __init__(self, client: PoliteClient) -> None:
        self._client = client
        self._health = threading.Condition()
        self._probe_in_progress = False
        self._probed = False
        self._disabled_reason = ""

    def is_available(self) -> bool:
        with self._health:
            return not self._disabled_reason

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        # Only the first request probes availability. Waiting queries must not
        # repeat a blocked probe; once healthy, ordinary searches run concurrently.
        with self._health:
            while self._probe_in_progress:
                self._health.wait()
            if self._disabled_reason:
                raise RuntimeError(self._disabled_reason)
            probing = not self._probed
            if probing:
                self._probe_in_progress = True
        try:
            return self._search_once(query, max_results)
        finally:
            if probing:
                with self._health:
                    self._probed = True
                    self._probe_in_progress = False
                    self._health.notify_all()

    def _disable(self, reason: str) -> None:
        # Reasons are fixed labels/status codes, never response text or queries.
        with self._health:
            self._disabled_reason = "DuckDuckGo unavailable: " + reason
        raise RuntimeError(self._disabled_reason)

    def _search_once(self, query: str, max_results: int) -> list[SearchResult]:
        # A timeout must bound one attempt, not every retry of every query.
        try:
            resp = self._client.post(self.URL, data={"q": query}, timeout=6.0,
                                     request_attempts=1)
        except Exception:  # noqa: BLE001 — optional search transport is non-fatal
            self._disable("request failed")
        if resp is None:
            self._disable("request failed")
        if resp.status_code in (202, 403, 429) or resp.status_code >= 500:
            self._disable(f"HTTP {resp.status_code}")
        if resp.status_code != 200:
            return []
        soup = BeautifulSoup(resp.text, "html.parser")
        if soup.select_one('form#challenge-form, form#img-form, form[action*="anomaly.js"], '
                           '.anomaly-modal, input[type="password"]'):
            self._disable("challenge page")
        out: list[SearchResult] = []
        for res in soup.select("div.result"):
            a = res.select_one("a.result__a")
            if not a or not a.get("href"):
                continue
            url = _unwrap_ddg(a["href"])
            if not url.startswith("http"):
                continue
            snip = res.select_one(".result__snippet")
            out.append(SearchResult(
                url=url,
                title=a.get_text(" ", strip=True),
                snippet=snip.get_text(" ", strip=True) if snip else "",
            ))
            if len(out) >= max_results:
                break
        return out


# --------------------------------------------------------------------------- #
# Fallback orchestrator
# --------------------------------------------------------------------------- #
class FallbackBackend:
    """Tries available backends in priority order until one yields results."""

    name = "fallback"

    def __init__(self, backends: list[SearchBackend]) -> None:
        self.backends = backends
        self.last_used = ""
        self.errors: list[str] = []
        self.attempts: list[dict] = []
        # The pipeline fans searches out across threads; guard shared state.
        self._lock = threading.Lock()

    def is_available(self) -> bool:
        return any(b.is_available() for b in self.backends)

    def _note(self, msg: str) -> None:
        with self._lock:
            if msg not in self.errors:            # errors accumulate across the
                self.errors.append(msg)           # concurrent run; keep it deduped

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        return self._search(query, max_results)

    def search_profiles(self, query: str, max_results: int = 20, *, platform: str,
                        name: str) -> list[SearchResult]:
        """Continue past directories and unrelated owners, retaining partial hits.

        A title/handle match is a retrieval stopping rule, not verified identity.
        Each configured provider is consulted at most once for this query.
        """
        return self._search(query, max_results, platform, name)

    def _search(self, query: str, max_results: int, platform: str = '',
                name: str = '') -> list[SearchResult]:
        from .candidates import _handle_from_url, is_name_match

        def qualifies(hit):
            handle = _handle_from_url(platform, hit.url)
            return bool(handle and is_name_match(name, hit, handle))

        def relevance(hit):
            return qualifies(hit), bool(_handle_from_url(platform, hit.url))

        kept: list[SearchResult] = []
        seen: set[tuple] = set()
        for_query = max(0, max_results)
        if not for_query:
            return []
        for b in self.backends:
            if not b.is_available():
                continue
            started = time.monotonic()
            record = {'query': query, 'provider': b.name, 'platform': platform, 'status': 'ok'}
            try:
                results = b.search(query, max_results=max_results)
            except Exception as e:  # noqa: BLE001
                record.update(status='error', error=type(e).__name__, results=0)
                detail = b._disabled_reason if isinstance(b, DuckDuckGoBackend) else ''
                if detail:
                    record['detail'] = detail
                self._note(f"{b.name}: {detail or type(e).__name__}")
                continue
            finally:
                record['seconds'] = round(time.monotonic() - started, 3)
                with self._lock:
                    self.attempts.append(record)
            results = [replace(hit, provider=hit.provider or b.name, query=query)
                       for hit in (results or [])]
            record.update(results=len(results), status='ok' if results else 'empty')
            if results:
                with self._lock:
                    self.last_used = b.name
                if not platform:
                    return results
                record['matching_profiles'] = sum(qualifies(hit) for hit in results)
                for hit in results:
                    key = (str(hit.url), hit.title, hit.snippet, hit.provider)
                    if key not in seen:
                        seen.add(key)
                        kept.append(hit)
                if record['matching_profiles']:
                    # Noise from an earlier provider must not push the recovered
                    # profile outside the result budget.
                    return sorted(kept, key=relevance, reverse=True)[:for_query]
            else:
                self._note(f"{b.name}: 0 results")
        return sorted(kept, key=relevance, reverse=True)[:for_query]


# Playwright is not a default *search* backend: scraping Bing via a headless
# browser costs ~15-20s per query and, in practice, adds nothing once
# Serper/SearXNG/DuckDuckGo have run. Re-add via OSINT_BACKEND_ORDER if needed.
_ORDER = ("serper", "google_cse", "searxng", "duckduckgo")


def build_backends(config: DiscoveryConfig | None,
                   client: PoliteClient) -> list[SearchBackend]:
    config = config or DiscoveryConfig.from_env()
    registry: dict[str, SearchBackend] = {
        "serper": SerperBackend(config.serper_key, client),
        "google_cse": GoogleCSEBackend(config.google_cse_key,
                                       config.google_cse_cx, client),
        "searxng": SearxngBackend(config.searxng_url, client),
        "playwright": PlaywrightBackend(),
        "duckduckgo": DuckDuckGoBackend(client),
    }
    order = config.backend_order or _ORDER
    return [registry[n] for n in order if n in registry]


def default_backend(client: PoliteClient | None = None,
                    config: DiscoveryConfig | None = None) -> FallbackBackend:
    client = client or PoliteClient()
    return FallbackBackend(build_backends(config, client))
