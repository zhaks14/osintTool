# osintTool — personalized password auditing (defensive)

A corporate password-hygiene tool. It builds a **per-person** password
wordlist from OSINT-derived information and judges whether a proposed
password is guessable from that same information — so an employee can't set
`khabibNurmagomedov777` when their public profile is all about Khabib.

Two ways it plugs in:

| Mode | When | How |
|------|------|-----|
| **Proactive** | at password-change time | AD password filter / self-service portal calls `evaluate_password()` and rejects weak choices |
| **Reactive** | scheduled audit | `generate_wordlist()` → hashcat/john against NT hashes dumped from the domain → report weak users |

> Passwords are never readable from AD (only NTLM hashes). Reactive =
> hash cracking; proactive = intercept the plaintext at the moment of change.

## Architecture

```
discovery/   ONLINE   find public profiles + pull public data
ml/          LOCAL    NER on text, optional image analysis, EXIF
osintpwd/    LOCAL    the offline password engine                    (done)
  models.py       Profile + Config
  transforms.py   leet / de-leet, affixes, case, combinations
  generator.py    Profile -> wordlist        (reactive)
  evaluator.py    password + Profile -> Verdict (proactive)
```

All ML inference runs **locally** (employee photos never leave the machine);
only the collection layer touches the network.

## Usage (offline engine)

```bash
# self-contained demonstration
python -m osintpwd demo

# generate a wordlist for hashcat/john
python -m osintpwd wordlist examples/profile.example.json -o words.txt

# check a single password (exit code 1 = rejected)
python -m osintpwd check examples/profile.example.json "khabibNurmagomedov777"
```

A profile is a JSON file; keys match the `Profile` dataclass in
`osintpwd/models.py`. See `examples/profile.example.json`.

## Tests

```bash
python tests/test_core.py        # or: python -m pytest tests/ -q
```

## Discovery (online)

```powershell
python -m osintpwd discover "Aslan Serikov" --city Almaty --employer AcmeBank
python -m osintpwd web
```

Open the dashboard at http://localhost:7020. Search proposes unconfirmed
accounts; select the appropriate profiles before analysing them.

### Direct search and evidence

The classifier recognises LinkedIn, Instagram, Facebook, VK, X, GitHub,
Telegram, TikTok and YouTube. Name variants are searched in Latin/Cyrillic;
city/employer/school hints add queries without removing the broad name search.
There are dedicated queries for the four primary networks, general web queries,
a combined query for the other networks, and targeted queries for uncovered
networks. Weak profile candidates remain visible. A name mentioned in someone
else's snippet is a weak lead, not an owner-name match.

Missing primary networks each get an unquoted recovery query even if another
network already matched. LinkedIn additionally tries a broader domain query
and a plain name + LinkedIn query, stopping at the first named profile (at most
three spelling variants per wave). Legacy `/pub/` and regional LinkedIn URLs
retain their observed account identifiers. No profile URL is invented from a name.
When no LinkedIn name match is retrieved, the dashboard says so and links to
LinkedIn's own people search; absence from a public index is not absence of an account.

Duplicate accounts merge their excerpts, query/provider provenance and matched
hints. Scores are heuristic ranks, not probabilities. Same-username groups are
explicitly hypotheses; punctuation-distinct usernames and contradictory owner
names are kept separate. JSON export contains the suggestions, evidence,
related-person chains, source excerpts and run statistics.

Sources are retained from every search pass, including public posts. Four
source pages and two profile pages are read by default, with at most three
parallel page reads. The source list favours accessible non-social pages and
varied hosts. Main HTML text plus metadata is extracted using Trafilatura with
a BeautifulSoup fallback. Text PDFs use pypdf (up to five pages); scanned PDFs
are not OCRed. The public reader streams at most 2 MiB and retains at most
24,000 text characters per document. It checks public HTTP(S) destinations and
redirects before requests; DNS preflight is not a network sandbox.

### Search through co-mentioned people

Automatic continuation runs when no owner-name candidate has been found;
weak suggestions do not stop it. The dashboard button “Ничего не подошло —
искать через упоминания” performs the same step explicitly, using the prior
source text, even when namesake candidates were found.

1. Extract up to two other names from short contexts containing the target's
   name or a spelling variant. spaCy is optional; multilingual rules supplement it.
2. Search their profiles and joint-name queries.
3. Read up to two associate profiles in total. Follow only one hop through
   explicit name-attached account links or platform-scoped mentions.
4. Preserve the original co-mention, intermediate account and final link as
   evidence. Keep associate accounts separate from target-account proposals.

Co-mention does not establish friendship or ownership. Publisher/footer links
are not treated as the target's accounts. Search and reader failures remain
visible with the partial results. A failed fallback and a successful fallback
with no people/accounts are distinguishable via flags, errors and counts.

`POST /api/discover` accepts name plus optional city/country/employer/job_title/
school. `POST /api/discover/related` accepts those fields and prior `web_info`.
Both use the same discovery code as the Python API. Responses include
`candidates`, `related_accounts`, `related_people`, `related_searched`,
`related_evidence`, `web_info`, `stats` and `notes`. Candidate records include
`evidence`, `match_reasons`, `relation`, `fetch_status` and `fetch_error`.

### Backends and bounded expansion

The default provider order is Serper, Google CSE, configured SearXNG, then
DuckDuckGo. Configure keys/URLs with `SERPER_API_KEY`, `GOOGLE_CSE_KEY`,
`GOOGLE_CSE_CX`, `SEARXNG_URL`. General web queries stop at the first nonempty
provider. Platform-specific queries continue past directories and unrelated
owners until a name-matching profile is retrieved or configured providers are
exhausted. Partial hits retain query/provider evidence. Query counts and provider
attempt counts are reported separately. This implementation does not use RRF or
multi-page search. Repeated equivalent queries within a run reuse their results;
generic and profile-qualified lookups have separate caches. Provider quotas and public indexes
change, so more requests do not guarantee more correct accounts.

`OSINT_BACKEND_ORDER` overrides the order. Optional Playwright/Bing search is
available through that setting; it is not a default provider or a page-rendering
stage. No Selenium dependency is needed. `OSINT_SEARXNG_ENGINES` configures the
engines requested from the configured SearXNG instance.

Username expansion uses up to two strong-name candidates by default and keeps
cross-network username matches weak and unconfirmed. The explicit “Расширить
по @...” action is also available. A matching username does not prove a shared
owner. Python callers can set `username_scan=False`, `fetch_pages=0`,
`enrich_profiles=0`, or `related_search="off"`; `related_search="always"` forces
the co-mention path. These controls are independent of ranking.

### Quality evaluation

```powershell
.venv\Scripts\python.exe -m pytest tests/test_discovery.py tests/test_discovery_classification.py tests/test_discovery_related.py tests/test_discovery_evaluate.py tests/test_discovery_pipeline.py tests/test_discovery_api.py tests/test_public_reader.py -q
.venv\Scripts\python.exe tests/discovery_benchmark.py --output after.json
.venv\Scripts\python.exe -m osintpwd.discovery.evaluate examples/discovery_eval.json --output live-quality.json
```

The fixed benchmark is synthetic and network-free. Live identity labels use
platform plus canonical URL, never a bare handle. Unknown candidates remain
unjudged, and precision is reported alongside label coverage. See
[the before/after report](docs/discovery-quality-report.md) and
[current design and limits](docs/discovery-research.md).

## Local ML enrichment

```bash
# offline: enrich a profile from harvested text and/or a photo folder
python -m osintpwd enrich profile.json --text-file posts.txt --images ./photos
```

Runs entirely on this machine (no cloud). Layers, each optional & lazy:

| Signal | Backend | Install | Status |
|--------|---------|---------|--------|
| EXIF / GPS / date | Pillow | (installed) | on |
| Interest gazetteer | built-in | — | on (Latin seed) |
| NER (rules) | built-in | — | on |
| NER (PERSON/LOC/ORG) | spaCy `xx_ent_wiki_sm` | `spacy` + model | on (multilingual) |
| Object tags | YOLOv8 | `ultralytics` | optional (GPU) |

`python -m osintpwd discover ... --enrich` pipes harvested text straight
through this layer into the draft profile.

### Identity confirmation via nomad face_recog (loose coupling)

Reuses the existing `nomad_mvp/modules/image-analyzer/face_recog` stack
(InsightFace + ArcFace + HDBSCAN) **without importing its heavy deps** — we
only read its `output/` folder. Purpose: confirm several discovered profiles
belong to the *same* person, fixing name-only ambiguity.

```bash
# 1. download each candidate's public profile photo
python -m osintpwd discover "Aslan Serikov" --city Almaty --photos-out ./photos

# 2. run the nomad face_recog pipeline on ./photos (its own Docker/env)
#    -> produces output/clusters/person_XXXX/

# 3. confirm they cluster as one identity
python -m osintpwd confirm ./face_recog/output --photos ./photos
#    same person across profiles: YES  (instagram_asik -> person_0000, ...)
```

> The sibling `object_part` module is threat/NSFW/violence detection — not
> relevant to password profiling, so it is intentionally not integrated.

## Status

- [x] Offline engine: wordlist + password evaluation (6/6 tests)
- [x] Online discovery: multi-backend search + classify + enrich
- [x] Article/PDF/DOCX text, source links and bounded co-mention fallback
- [x] Confidence ranking: results ordered top→bottom by corroboration (no filtering)
- [x] Name-only web search, source reading and evidence-backed account suggestions
- [x] Username pivoting: one handle → the same person on 17 more networks
- [x] Cyrillic→Latin transliteration (RU/KZ names searched in both scripts)
- [x] Optional Maigret deep scan (~3000 sites), opt-in button
- [x] Local ML enrichment: EXIF, gazetteer, rule+spaCy NER (7/7 tests)
- [x] Identity confirmation via nomad face_recog output reader (4/4 tests)
- [x] Web dashboard (FastAPI): discover → analyze → live check → wordlist
- [x] SearXNG discovery backend (Docker, free, no key)
- [ ] Active Directory integration (password filter / hash audit)
- [ ] Reporting (JSON / HTML)

## Web dashboard

```bash
.venv\Scripts\Activate.ps1             # activate the venv first (Windows PowerShell)
# source .venv/bin/activate            #   ... or on macOS/Linux
cd deploy && docker compose up -d      # start SearXNG (free search backend)
cd ..
python -m osintpwd web                  # http://localhost:7020 (auto-attaches SearXNG)
```

> The dashboard on `:7020` is served by this `python -m osintpwd web` process, **not**
> by Docker — Docker only runs SearXNG on `:8080`. Activate the venv and keep the
> `web` command running; then open http://localhost:7020 (not `:8080`).

Flow: enter **name + surname only** → **Найти по всему вебу** (Google · Yandex ·
Bing · DuckDuckGo · Brave) → results split into two columns — **👤 Соцсети**
(IG/FB/LinkedIn profiles = the found people) and **🌐 Инфо по человеку** (news,
university, blog, forum, **documents (PDF/DOCX/…)** and **research/academic**
hits). Each web hit is colour-matched to the person it correlates with (with a
`↳ персона N · reason` tag naming the link); hits tied to nobody sit dimmed under
a «не связано с найденными» divider → tick the right cards → **Анализировать
выбранные** (fetch public text + ML) → live password check + wordlist. The web
command auto-detects SearXNG on :8080.

### Reading Instagram posts (burner session)

Anonymous Instagram is blocked, so post/bio reading needs a logged-in session.
Use a **throwaway/burner** IG account (never a personal one — IG may ban it):

```powershell
python -m osintpwd ig-login <burner_username>   # password entered locally, not stored
$env:IG_USERNAME = "<burner_username>"
python -m osintpwd web                            # analysis now reads IG bio + captions
```

The password is read via getpass and never logged; only the session token is
saved (under %APPDATA%\osintpwd\ig_sessions or `IG_SESSION_DIR`). LinkedIn
already yields public text without login; Facebook is mostly login-walled too.

## Scope

The discovery component implements public-account suggestions and a bounded
co-mention fallback. See the current discovery section and quality report above;
old quick/balanced/deep, RRF, browser-page rendering and rejection-state controls
are not part of the current interface.

Defensive use only: auditing your own organisation's password hygiene with
authorization. Not for compromising third-party accounts.
